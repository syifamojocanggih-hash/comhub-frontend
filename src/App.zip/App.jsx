﻿import { useState } from 'react'

const sidebarItems = [
  { label: 'Dashboard', icon: '🏠' },
  { label: 'Project Tracking', icon: '📊' },
  { label: 'Financial', icon: '💰' },
  { label: 'Member', icon: '👥' },
  { label: 'Settings', icon: '⚙️' },
]

const quickStats = [
  { label: 'Total Komunitas Aktif Saat ini', value: '20', icon: '👥', accent: 'bg-cyan-500/20 text-cyan-300' },
  { label: 'Program Kerja berjalan', value: '12', icon: '⚡', accent: 'bg-violet-500/20 text-violet-300' },
  { label: 'Total anggota keseluruhan', value: '450', icon: '👤', accent: 'bg-sky-500/20 text-sky-300' },
]

const popularCommunities = [
  { name: 'Pala Pens LA', description: 'Komunitas pecinta alam PENS PSDKU Lamongan.', members: '120' },
  { name: 'RoboTech LA', description: 'Eksplorasi robotika, IoT, dan inovasi industri.', members: '90' },
  { name: 'Creative Pixel', description: 'Belajar UI/UX dan branding visual kreatif.', members: '70' },
  { name: 'Dev-Force Lamongan', description: 'Developer muda belajar web dan competitive programming.', members: '56' },
  { name: 'G-Force Esports', description: 'Komunitas e-sports kompetitif kuliah aktif.', members: '55' },
]

const hubCards = [
  {
    title: 'Komunitas Pala',
    subtitle: 'Komunitas Pecinta Alam melakukan kegiatan bersama',
    image: '/pala-hero.svg',
  },
  {
    title: 'Komunitas Robotic',
    subtitle: 'Potret praktik anak komunitas robotic di lab PENS',
    image: '/robotic-hero.svg',
  },
]

const communityInfo = {
  title: 'ComHub Community Info',
  description: 'Platform ini menampilkan komunitas aktif, kegiatan berjalan, dan rekomendasi komunitas populer dalam satu dashboard modern.',
  stats: [
    { label: 'Slides', value: '24' },
    { label: 'Aktivitas', value: '18' },
    { label: 'Rating', value: '4.9/5' },
  ],
  notes: ['Terapkan event mingguan', 'Integrasi data anggota', 'Optimasi onboarding peserta'],
}

function App() {
  const [activeTab, setActiveTab] = useState('Dashboard')
  const [selectedCommunity, setSelectedCommunity] = useState(popularCommunities[0])

  return (
    <div className="min-h-screen bg-[#060b1b] text-slate-100">
      <div className="lg:flex lg:min-h-screen">
        <aside className="lg:w-80 w-full bg-[#050918] border-slate-800 border-b lg:border-b-0 lg:border-r p-6 flex flex-col">
          <div className="mb-10">
            <div className="inline-flex items-center gap-3 rounded-3xl bg-slate-900/80 px-4 py-4 shadow-sm shadow-cyan-500/10">
              <div className="h-12 w-12 rounded-3xl bg-gradient-to-br from-cyan-400 to-blue-500 grid place-items-center text-xl text-slate-950 font-bold">
                C
              </div>
              <div>
                <p className="text-sm text-slate-400">Comhub</p>
                <h1 className="text-lg font-semibold text-white">Community Dashboard</h1>
              </div>
            </div>
          </div>

          <nav className="space-y-3">
            {sidebarItems.map((item) => {
              const isActive = item.label === activeTab
              return (
                <button
                  key={item.label}
                  onClick={() => setActiveTab(item.label)}
                  className={`w-full flex items-center gap-4 rounded-3xl px-4 py-3 text-left text-sm font-medium transition ${
                    isActive
                      ? 'bg-gradient-to-r from-slate-800 via-slate-900 to-slate-950 text-cyan-200 shadow-lg shadow-cyan-500/10'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span className="text-lg">{item.icon}</span>
                  {item.label}
                </button>
              )
            })}
          </nav>

          <div className="mt-auto rounded-[2rem] border border-slate-800 bg-slate-950/20 p-5 shadow-inner shadow-slate-950/10">
            <p className="text-xs uppercase tracking-[0.3em] text-slate-500 mb-3">Need help?</p>
            <p className="text-sm text-slate-300 leading-6">Akses pengaturan komunitas dan update fitur kapan saja dari sidebar.</p>
          </div>
        </aside>

        <main className="flex-1 p-6 lg:p-8">
          <header className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <p className="text-sm text-slate-500">Dashboard / ComHub</p>
              <h2 className="text-3xl font-semibold text-white">Modern Dark Community Dashboard</h2>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="relative w-full sm:w-96">
                <span className="pointer-events-none absolute inset-y-0 left-4 flex items-center text-slate-400">🔎</span>
                <input
                  type="search"
                  placeholder="Search Community..."
                  className="w-full rounded-3xl border border-slate-800 bg-slate-900/90 py-3 pl-11 pr-4 text-sm text-slate-100 outline-none transition focus:border-cyan-400"
                />
              </div>
              <div className="flex items-center gap-3 rounded-3xl border border-slate-800 bg-slate-900/90 px-4 py-3">
                <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-700 text-lg">AS</div>
                <div>
                  <p className="text-sm text-slate-400">Ahmad Syifa’ul</p>
                  <p className="text-xs text-slate-500">Admin Community</p>
                </div>
              </div>
            </div>
          </header>

          <section className="mt-8 grid gap-6 lg:grid-cols-3">
            {quickStats.map((item) => (
              <div key={item.label} className="rounded-[2rem] border border-slate-800 bg-slate-900/90 p-6 shadow-lg shadow-slate-950/20">
                <div className={`inline-flex items-center gap-3 rounded-full px-3 py-2 ${item.accent}`}>
                  <span>{item.icon}</span>
                  <p className="text-xs uppercase tracking-[0.3em] text-slate-200">{item.label}</p>
                </div>
                <p className="mt-7 text-4xl font-semibold text-white">{item.value}</p>
                <p className="mt-2 text-sm text-slate-400">Statistik komunitas terbaru</p>
              </div>
            ))}
          </section>

          <section className="mt-8 grid gap-6 xl:grid-cols-[1.45fr_1fr]">
            <div className="space-y-6">
              <div className="rounded-[2rem] border border-slate-800 bg-slate-900/90 p-6 shadow-lg shadow-slate-950/10">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-semibold text-white">Popular Community in This Month</h3>
                    <p className="text-sm text-slate-500">List komunitas yang paling banyak dikunjungi.</p>
                  </div>
                  <span className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-400">Monthly</span>
                </div>

                <div className="mt-6 space-y-4">
                  {popularCommunities.map((community, index) => {
                    const active = community.name === selectedCommunity.name
                    return (
                      <button
                        key={community.name}
                        onClick={() => setSelectedCommunity(community)}
                        className={`w-full rounded-3xl border p-4 text-left transition ${
                          active
                            ? 'border-cyan-400/30 bg-slate-800/90 shadow-lg shadow-cyan-500/10'
                            : 'border-slate-800 bg-slate-950/70 hover:border-slate-600 hover:bg-slate-900'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div className="h-12 w-12 rounded-3xl bg-slate-800 grid place-items-center text-sm font-semibold text-slate-300">{index + 1}</div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between gap-4">
                              <h4 className="font-semibold text-white">{community.name}</h4>
                              <span className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-400">{community.members}</span>
                            </div>
                            <p className="mt-2 text-sm text-slate-400">{community.description}</p>
                          </div>
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>

              <div className="rounded-[2rem] border border-slate-800 bg-slate-900/90 p-6 shadow-lg shadow-slate-950/10">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-semibold text-white">Info Community</h3>
                    <p className="text-sm text-slate-500">Ringkasan dan insight komunitas.</p>
                  </div>
                  <button className="rounded-3xl border border-slate-800 px-4 py-2 text-sm text-slate-300 hover:bg-slate-800">Detail</button>
                </div>

                <div className="mt-6 grid gap-4 sm:grid-cols-3">
                  {communityInfo.stats.map((stat) => (
                    <div key={stat.label} className="rounded-3xl border border-slate-800 bg-slate-950/70 p-4 text-center">
                      <p className="text-3xl font-semibold text-white">{stat.value}</p>
                      <p className="mt-2 text-sm text-slate-500">{stat.label}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-6 rounded-[2rem] border border-slate-800 bg-slate-950/70 p-5">
                  <h4 className="font-semibold text-white">{communityInfo.title}</h4>
                  <p className="mt-3 text-sm leading-6 text-slate-400">{communityInfo.description}</p>
                </div>

                <div className="mt-6 space-y-3">
                  {communityInfo.notes.map((note) => (
                    <div key={note} className="flex items-start gap-3 rounded-3xl border border-slate-800 bg-slate-900/90 p-4">
                      <span className="mt-1 h-2.5 w-2.5 rounded-full bg-cyan-400" />
                      <p className="text-sm text-slate-400">{note}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <aside className="space-y-6">
              <div className="rounded-[2rem] border border-slate-800 bg-slate-900/90 p-6 shadow-lg shadow-slate-950/10">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-semibold text-white">Hub</h3>
                    <p className="text-sm text-slate-500">Highlight komunitas terbaru dan galeri kegiatan.</p>
                  </div>
                  <span className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-400">Gallery</span>
                </div>

                <div className="mt-6 grid gap-4">
                  {hubCards.map((card) => (
                    <div key={card.title} className="relative overflow-hidden rounded-[2rem] border border-slate-800 bg-slate-950/70">
                      <img src={card.image} alt={card.title} className="h-48 w-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/20 to-transparent" />
                      <div className="absolute bottom-5 left-5 right-5">
                        <p className="text-xs uppercase tracking-[0.28em] text-slate-400">{card.title}</p>
                        <h4 className="mt-2 text-xl font-semibold text-white">{card.subtitle}</h4>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </aside>
          </section>
        </main>
      </div>
    </div>
  )
}

export default App
